#include <stdio.h>

int main(void) 
{
    printf("%10.3f", 152.49861); // 첫 번째 코드 
    printf("\n\n");
    printf("you\tcan\tmake\tit\n"); // 두 번째 코드 
    printf("\n\n");
    printf("\"Everybody say \'hello\'!\""); // 세 번째 코드
    
    return 0;
}