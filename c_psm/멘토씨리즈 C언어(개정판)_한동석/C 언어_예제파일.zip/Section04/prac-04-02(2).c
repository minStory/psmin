#include <stdio.h>

int main(void) 
{
    printf("%5s\n", "*");  
    printf("%6s\n", "***");
    printf("%7s\n", "*****");
    printf("%8s\n", "*******");
    
    return 0;
}