#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>

int main(void) 
{
    int number;
    
    printf("값을 입력하세요 : ");
    scanf("%d", &number);
    printf("입력 값 : %d\n", number);
    
    return 0;
}