#include <stdio.h>

int main(void)
{
    printf("I Love C language!\n");
    printf("It is so funny!\n");
    
    return 0;
}