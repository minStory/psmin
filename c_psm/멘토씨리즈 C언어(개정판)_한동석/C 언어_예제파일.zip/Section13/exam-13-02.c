#include <stdio.h>

int main(void) 
{
    int ch1, ch2;

    ch1 = getchar();
    ch2 = getchar(); 

    putchar(ch1); putchar(ch2);

    return 0;
}