#include <stdio.h>

int main(void) 
{
    int num = 20;
    char aaa = 'a'; 
    printf("%c\n", aaa); 
    printf("%d\n", num);
    
    return 0; 
}