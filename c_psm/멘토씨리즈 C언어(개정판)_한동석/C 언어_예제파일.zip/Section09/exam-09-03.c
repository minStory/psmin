#include <stdio.h>

int main(void) 
{
    char greet[] = "Hello, Guys!";
    printf("1차원 배열 greet의 길이는 : %d\n", sizeof(greet));

    return 0;
}