#include <stdio.h>

int main(void) 
{
    // 길이 정보가 포함된 배열의 선언 및 초기화
    int numbers[3] = {1, 2, 3}; 

    // 길이 정보가 포함되지 않은 배열의 선언 및 초기화
    char characters[5] = {'a', 'b', 'c', 'd', 'e'};

    return 0;
}