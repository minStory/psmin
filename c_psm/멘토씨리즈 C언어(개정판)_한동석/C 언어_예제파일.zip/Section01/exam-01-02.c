/*
파일명 : exam-01-02.c
작성자 : 강윤호
수정날짜 : 2020-10-20
기능 : printf 함수를 통한 문자열 출력
*/
#include <stdio.h> // 표준함수 사용을 위한 헤더파일 선언. 

int main(void)
{
    printf("Hello!"); // Hello! 를 출력하자.
    
    return 0;
}