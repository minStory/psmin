#include <stdio.h>

int main(void)
{
    char alpha = 'A';

    if(alpha == 'B') 
        printf("alpha is B.");
    else 
        printf("alpha is not B.");

    return 0;
}