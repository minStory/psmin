#include <stdio.h>

int main(void)
{
    int num = 3;

    if(num < 3) 
        printf("num is smaller than 3!");

    if(num == 3) 
        printf("num is 3!");

    if(num > 3) 
        printf("num is bigger than 3!");

    return 0;
}