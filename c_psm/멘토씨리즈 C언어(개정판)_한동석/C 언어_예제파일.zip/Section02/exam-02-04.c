#include <stdio.h>

int main(void) 
{
    printf("%d\n", sizeof(100));
    printf("%d\n", sizeof(3.14));
    
    return 0;
}