#include <stdio.h>

int main(void)
{
    int number1, number2; // 두 개의 int형 변수를 한 번에 선언
    number1 = 1;
    number2 = 2;
    int number3 = 3, number4 = 4; // 선언과 초기화 동시 진행

    return 0;
}