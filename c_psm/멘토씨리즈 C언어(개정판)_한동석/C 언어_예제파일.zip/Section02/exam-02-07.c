#include <stdio.h>

int main(void) 
{
    double number1 = 10;
    int number2 = 1.2345;
    short number3 = 70000;

    printf("%f\n", number1);
    printf("%d\n", number2);
    printf("%d\n", number3);
    
    return 0;
}
