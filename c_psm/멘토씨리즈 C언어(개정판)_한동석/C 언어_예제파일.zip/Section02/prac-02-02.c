#include <stdio.h> 

int main(void)
{
    printf("%d\n", sizeof(int));
    printf("%d\n", sizeof(char)); 
    printf("%d\n", sizeof(short)); 
    printf("%d\n", sizeof(50)); 
    printf("%d\n", sizeof(float)); 
    printf("%d\n", sizeof(3.14));
    
    return 0; 
}