#include <stdio.h>

int main(void)
{
    int number1 = 3;
    printf("%d\n", number1); 
    int number2 = 5;
    printf("%d\n", number2); 

    return 0;
}