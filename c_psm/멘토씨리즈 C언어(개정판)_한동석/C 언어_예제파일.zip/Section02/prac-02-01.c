#include <stdio.h> 

int main(void) 
{
    printf("오늘의 주제 : 변수와 자료형\n");
    printf("프로그램 작성자 : 홍길동\n");
    printf("프로그램 작성일 : 2021.02.23\n");
    
    return 0;
}