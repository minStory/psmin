#include <stdio.h>

int main(void) 
{
    printf("%d\n", (short)3.1415);
    printf("%d\n", (int)3.1415);
    printf("%f\n", (double)10);
    printf("%f\n", (float)10);

    return 0;
}