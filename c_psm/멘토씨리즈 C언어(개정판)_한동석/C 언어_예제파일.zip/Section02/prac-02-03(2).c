#include <stdio.h> 

int main(void)
{
    // float f = 3.14; // 데이터 손실 가능성이 있습니다
    double d = 3.14;
    
    return 0; 
}