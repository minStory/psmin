#include <stdio.h> 

int main(void)
{
    int num = 5;

    printf("%d\n", ++num);
    printf("%d\n", num++);
    printf("%d\n", ++num);

    return 0; 
}