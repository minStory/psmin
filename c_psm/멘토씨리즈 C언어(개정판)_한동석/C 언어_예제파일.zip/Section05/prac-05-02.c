#include <stdio.h> 

int main( )
{
    int num1 = 27;

    printf("%d\n", num1 > 10); 
    printf("%d\n", num1 != 5);

    printf("%d\n", num1 >= 27); 
    printf("%d\n", num1 == 27);

    printf("%d\n", num1 < 30); 
    printf("%d\n", num1 <= 27);

    return 0; 
}