#include <stdio.h>

int main(void) 
{
    // 변수의 선언 
    int a = 10, b = 11;

    printf("a == b : %d\n", a == b); 
    printf("a > b : %d\n", a > b); 
    printf("a < b : %d\n", a < b); 
    printf("a >= b : %d\n", a >= b); 
    printf("a <= b : %d\n", a <= b); 
    printf("a != b : %d\n", a != b);

    return 0;
}