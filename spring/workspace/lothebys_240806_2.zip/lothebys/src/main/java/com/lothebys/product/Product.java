package com.lothebys.product;

public class Product {
}
