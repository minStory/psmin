package com.lothebys;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LothebysApplicationTests {

	@Test
	void contextLoads() {
	}

}
