package com.latte;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LatteApplicationTests {

	@Test
	void contextLoads() {
	}

}
