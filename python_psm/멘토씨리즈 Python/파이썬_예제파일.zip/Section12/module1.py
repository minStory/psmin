import converter

miles = converter.kilometer_to_miles(150)
print('150km={}miles'.format(miles))

pounds = converter.gram_to_pounds(1000)
print('1000g={}pounds'.format(pounds))
