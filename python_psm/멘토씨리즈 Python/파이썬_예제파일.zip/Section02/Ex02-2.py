name = 'Alice'
age = 25
address = '''우편번호 12345
서울시 영등포구 여의도동
서울빌딩 501호'''
boyfriend = None
height = 168.5

print(name)
print(age)
print(address)
print(boyfriend)
print(height)
