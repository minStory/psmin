s = 'maple'
middle = s[len(s) // 2]
print(s, '의 가운데 글자는', middle, '입니다.')
