student = '31025'
grade_no = student[0]
class_no = student[1:3]
stu_no = student[3:]  # stu_no = student[-2:] 도 가능합니다.
print(grade_no, '학년', class_no, '반', stu_no, '번')
