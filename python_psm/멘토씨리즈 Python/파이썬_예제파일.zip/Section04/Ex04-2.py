a, b = 10, 20
print('a = %d, b = %d' % (a, b))
a, b = b, a
print('a = %d, b = %d' % (a, b))
