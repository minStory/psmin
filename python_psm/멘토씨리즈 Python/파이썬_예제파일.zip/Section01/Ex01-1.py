print('Hello Python!')
