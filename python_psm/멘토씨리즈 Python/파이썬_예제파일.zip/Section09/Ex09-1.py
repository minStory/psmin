expr = input('계산식을 입력하세요 >>> ')
result = eval(expr)
print(expr + '=' + str(result))
