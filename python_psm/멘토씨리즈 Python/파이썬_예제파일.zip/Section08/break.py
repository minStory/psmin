n = 1
while True:
    print(n)
    if n == 10:
        break
    n += 1
