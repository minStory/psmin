n = 10
while n >= 1:
    print(n)
    n -= 1
