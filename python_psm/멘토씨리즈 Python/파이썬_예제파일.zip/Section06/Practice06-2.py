n = 1
while n <= 100:
    if n % 7 == 0:
        print(n)
    n += 1

# 또는

n = 7
while n <= 100:
    print(n)
    n += 7
