dan = 2
while dan <= 9:
    n = 1
    while n <= 9:
        print('{}×{}={}'.format(dan, n, dan * n))
        n += 1
    dan += 1
