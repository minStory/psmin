name = input('이름을 입력하세요 >>> ')
age = input('나이를 입력하세요 >>> ')

print('입력된 이름은 {}입니다.'.format(name))
print('입력된 나이는 {}살입니다.'.format(age))
