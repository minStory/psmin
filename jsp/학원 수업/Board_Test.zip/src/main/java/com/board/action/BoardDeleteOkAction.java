package com.board.action;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.board.model.BoardDAO;
import com.board.model.BoardDTO;

public class BoardDeleteOkAction implements Action{

	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String db_pwd = request.getParameter("db_pwd").trim();
		int page = Integer.parseInt(request.getParameter("page").trim());
		int no = Integer.parseInt(request.getParameter("no").trim());
		
		String pwd = request.getParameter("pwd").trim();
		
		BoardDAO dao = BoardDAO.getInstance();
		
		BoardDTO dto = dao.getBoardContent(no);
		
		PrintWriter w = response.getWriter();
		w.println("<script>");
		if(pwd.equals(db_pwd)) {
			// 비밀번호가 같은 경우
			int check = dao.updateBoard(dto);
			
			System.out.println("check = " + check);
			
			w.println("<script>");
			if(check > 0) {
				w.println("alert('게시물 삭제 성공!')");
				w.println("location.href='board_content.do?no=" + no + "&page=" + page +"'");
			}else {
				w.println("alert('게시물 삭제 실패..')");
				w.println("history.back()");
			}
			w.println("</script>");
		}else {
			// 비밀번호가 틀린 경우
			w.println("<script>");
			w.println("alert('비밀번호가 틀렸습니다!!')");
			w.println("history.back()");
			w.println("</script>");
		}
	}

}
